// Function to open the sidebar
function openNav() {
    document.getElementById("mySidebar").classList.add('open');
    document.body.classList.add('sidebar-open');
  }
  
  // Function to close the sidebar
  function closeNav() {
    document.getElementById("mySidebar").classList.remove('open');
    document.body.classList.remove('sidebar-open');
  }
  